package com.example.quanlydeadline.controllers;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlydeadline.R;
import com.example.quanlydeadline.adapters.TaskAdapter;
import com.example.quanlydeadline.database.AppDatabase;
import com.example.quanlydeadline.database.FirebaseSyncManager;
import com.example.quanlydeadline.database.TaskDao;
import com.example.quanlydeadline.models.Task;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class ProjectDetailActivity extends AppCompatActivity implements TaskAdapter.OnTaskActionListener {

    public static final String EXTRA_PROJECT_ID = "project_id";
    public static final String EXTRA_PROJECT_NAME = "project_name";

    private TextView tvEmpty, tvProgress, tvPercent;
    private ProgressBar progressOverall;
    private TaskAdapter adapter;
    private TaskDao taskDao;
    private FirebaseSyncManager syncManager;
    private int projectId;
    private long selectedDueDate = 0;

    // Tab filter: "todo", "inprogress", "done", "overdue"
    private String currentTab = "todo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_detail);

        projectId = getIntent().getIntExtra(EXTRA_PROJECT_ID, -1);
        String projectName = getIntent().getStringExtra(EXTRA_PROJECT_NAME);

        if (projectId == -1) {
            Toast.makeText(this, "Không tìm thấy đồ án", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Header
        TextView tvTitle = findViewById(R.id.tvProjectDetailTitle);
        tvTitle.setText(projectName != null ? projectName : "Chi tiết đồ án");

        // Nút back
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Views
        tvEmpty = findViewById(R.id.tvEmptyTasks);
        tvProgress = findViewById(R.id.tvTaskProgress);
        tvPercent = findViewById(R.id.tvProjectPercent);
        progressOverall = findViewById(R.id.progressOverall);

        RecyclerView recyclerView = findViewById(R.id.recyclerTasks);

        // ✅ Đúng kiểu — ExtendedFloatingActionButton
        ExtendedFloatingActionButton fabAdd = findViewById(R.id.fabAddTask);

        taskDao = AppDatabase.getDatabase(this).taskDao();
        syncManager = new FirebaseSyncManager();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(this);
        recyclerView.setAdapter(adapter);

        fabAdd.setOnClickListener(v -> showTaskDialog(null));

        // Setup tabs
        setupTabs();

        // Fetch tasks từ Firestore về Room
        syncManager.fetchAndSaveTasks(projectId, taskDao, () ->
                runOnUiThread(() -> loadTasks())
        );

        loadTasks();
    }

    private void setupTabs() {
        TextView tabTodo = findViewById(R.id.tabTodo);
        TextView tabInProgress = findViewById(R.id.tabInProgress);
        TextView tabDone = findViewById(R.id.tabDone);
        TextView tabOverdue = findViewById(R.id.tabOverdue);

        tabTodo.setOnClickListener(v -> { currentTab = "todo"; updateTabUI(tabTodo, tabInProgress, tabDone, tabOverdue); loadTasks(); });
        tabInProgress.setOnClickListener(v -> { currentTab = "inprogress"; updateTabUI(tabInProgress, tabTodo, tabDone, tabOverdue); loadTasks(); });
        tabDone.setOnClickListener(v -> { currentTab = "done"; updateTabUI(tabDone, tabTodo, tabInProgress, tabOverdue); loadTasks(); });
        tabOverdue.setOnClickListener(v -> { currentTab = "overdue"; updateTabUI(tabOverdue, tabTodo, tabInProgress, tabDone); loadTasks(); });
    }

    private void updateTabUI(TextView active, TextView... inactives) {
        active.setBackgroundResource(R.drawable.tab_selected_bg);
        active.setTextColor(0xFFFFFFFF);
        active.setTypeface(null, android.graphics.Typeface.BOLD);
        for (TextView tab : inactives) {
            tab.setBackgroundColor(android.graphics.Color.TRANSPARENT);
            tab.setTextColor(0xFFC7D9FF);
            tab.setTypeface(null, android.graphics.Typeface.NORMAL);
        }
    }

    private void loadTasks() {
        List<Task> allTasks = taskDao.getTasksByProject(projectId);
        List<Task> filtered = filterTasks(allTasks);
        adapter.setTasks(filtered);
        tvEmpty.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);
        updateProgress(allTasks);
    }

    private List<Task> filterTasks(List<Task> all) {
        List<Task> result = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Task t : all) {
            switch (currentTab) {
                case "todo":
                    if (!t.isDone && (t.dueDate == 0 || t.dueDate > now)) result.add(t);
                    break;
                case "inprogress":
                    if (!t.isDone) result.add(t);
                    break;
                case "done":
                    if (t.isDone) result.add(t);
                    break;
                case "overdue":
                    if (!t.isDone && t.dueDate > 0 && t.dueDate < now) result.add(t);
                    break;
            }
        }
        return result;
    }

    private void updateProgress(List<Task> allTasks) {
        int total = allTasks.size();
        int done = 0;
        for (Task t : allTasks) if (t.isDone) done++;

        tvProgress.setText(String.format(Locale.getDefault(), "%d/%d tasks", done, total));

        int percent = total > 0 ? (done * 100 / total) : 0;
        tvPercent.setText(percent + "%");
        progressOverall.setProgress(percent);
    }

    private void showTaskDialog(Task existingTask) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        EditText edtTitle = dialogView.findViewById(R.id.edtTaskTitle);
        EditText edtNote = dialogView.findViewById(R.id.edtTaskNote);
        TextView tvPickDate = dialogView.findViewById(R.id.tvPickTaskDueDate);

        boolean isEdit = existingTask != null;
        selectedDueDate = isEdit ? existingTask.dueDate : 0;

        if (isEdit) {
            edtTitle.setText(existingTask.title);
            edtNote.setText(existingTask.note);
        }
        updatePickDateLabel(tvPickDate);
        tvPickDate.setOnClickListener(v -> showDateTimePicker(tvPickDate));

        new AlertDialog.Builder(this)
                .setTitle(isEdit ? "Sửa deadline" : "Thêm deadline mới")
                .setView(dialogView)
                .setPositiveButton(isEdit ? "Lưu" : "Thêm", (dialog, which) -> {
                    String title = edtTitle.getText().toString().trim();
                    String note = edtNote.getText().toString().trim();

                    if (title.isEmpty()) {
                        Toast.makeText(this, "Vui lòng nhập tên công việc", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (isEdit) {
                        existingTask.title = title;
                        existingTask.note = note;
                        existingTask.dueDate = selectedDueDate;
                        taskDao.updateTask(existingTask);
                        syncManager.syncTask(existingTask);
                        Toast.makeText(this, "Đã cập nhật", Toast.LENGTH_SHORT).show();
                    } else {
                        Task newTask = new Task(projectId, title, note, selectedDueDate, false);
                        long newId = taskDao.insertTask(newTask);
                        newTask.id = (int) newId;
                        syncManager.syncTask(newTask);
                        Toast.makeText(this, "Đã thêm", Toast.LENGTH_SHORT).show();
                    }
                    loadTasks();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showDateTimePicker(TextView tvPickDate) {
        Calendar calendar = Calendar.getInstance();
        if (selectedDueDate > 0) calendar.setTimeInMillis(selectedDueDate);

        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar picked = Calendar.getInstance();
            picked.set(year, month, dayOfMonth);
            new TimePickerDialog(this, (timeView, hourOfDay, minute) -> {
                picked.set(Calendar.HOUR_OF_DAY, hourOfDay);
                picked.set(Calendar.MINUTE, minute);
                picked.set(Calendar.SECOND, 0);
                selectedDueDate = picked.getTimeInMillis();
                updatePickDateLabel(tvPickDate);
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void updatePickDateLabel(TextView tvPickDate) {
        if (selectedDueDate > 0) {
            tvPickDate.setText(android.text.format.DateFormat.format("dd/MM/yyyy HH:mm", selectedDueDate));
        } else {
            tvPickDate.setText("Chọn hạn nộp (tùy chọn)");
        }
    }

    @Override
    public void onTaskCheckedChange(Task task, boolean isChecked) {
        taskDao.setTaskDone(task.id, isChecked);
        task.isDone = isChecked;
        syncManager.syncTask(task);
        loadTasks();
    }

    @Override
    public void onTaskEdit(Task task) {
        showTaskDialog(task);
    }

    @Override
    public void onTaskDelete(Task task) {
        new AlertDialog.Builder(this)
                .setTitle("Xóa deadline")
                .setMessage("Bạn có chắc muốn xóa \"" + task.title + "\"?")
                .setPositiveButton("Xóa", (dialog, which) -> {
                    taskDao.deleteTask(task);
                    loadTasks();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }
}